\
/* src/main.cpp */
#include "app/NovaApp.h"

int main(int argc, char** argv) {
  NovaApp app(argc, argv);
  return app.run();
}
